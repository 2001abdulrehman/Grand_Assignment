<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "candy";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch candy data
$sql = "SELECT * FROM candy";

$result = $conn->query($sql);

$candyList = array();

if ($result->num_rows > 0) {
    // Fetch candy data and add it to the list
    while ($row = $result->fetch_assoc()) {
        $candyItem = array(
            'id' => $row['id'],
            'name' => $row['name'],
            'brand' => $row['brand'],
            'flavor' => $row['flavor'],
            'price' => $row['price'],
            'favorite' => $row['favorite']
        );
        $candyList[] = $candyItem;
    }
}

$conn->close();

// Return the candy data as a JSON response
header('Content-Type: application/json');
echo json_encode($candyList);
?>
