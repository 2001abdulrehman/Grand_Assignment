package com.example.isellcandy;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity {

    private ListView candyListView;
    private ArrayList<CandyItem> candyList;
    private CandyListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        candyListView = findViewById(R.id.candyListView);

        // Register the ListView for context menu
        registerForContextMenu(candyListView);

        // Call PHP script to fetch candy data from the database
        fetchCandyData();
    }

    private void fetchCandyData() {
        // TODO: Replace "your-php-script-url" with the actual URL of your PHP script
        String phpScriptUrl = "http://192.168.118.1/php/isellcandy.php";

        // Perform the network request in a background thread
        new FetchCandyDataAsyncTask().execute(phpScriptUrl);
    }

    private class FetchCandyDataAsyncTask extends AsyncTask<String, Void, ArrayList<CandyItem>> {

        @Override
        protected ArrayList<CandyItem> doInBackground(String... params) {
            String phpScriptUrl = params[0];
            ArrayList<CandyItem> candyList = new ArrayList<>();

            try {
                URL url = new URL(phpScriptUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                // Read the response from the PHP script
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                reader.close();
                connection.disconnect();

                // Parse the JSON response
                JSONArray jsonArray = new JSONArray(response.toString());

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                    int id = jsonObject.getInt("id");
                    String name = jsonObject.getString("name");
                    String brand = jsonObject.getString("brand");
                    String flavor = jsonObject.getString("flavor");
                    double price = jsonObject.getDouble("price");
                    int favorite = jsonObject.getInt("favorite");

                    CandyItem candyItem = new CandyItem(id, name, brand, flavor, price, favorite);
                    candyList.add(candyItem);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return candyList;
        }

        @Override
        protected void onPostExecute(ArrayList<CandyItem> candyList) {
            MainActivity.this.candyList = candyList;

            // Populate the ListView with the candy data
            adapter = new CandyListAdapter(MainActivity.this, candyList);
            candyListView.setAdapter(adapter);
        }
    }

    public class CandyItem {
        private int id;
        private String name;
        private String brand;
        private String flavor;
        private double price;
        private int favorite;

        public CandyItem(int id, String name, String brand, String flavor, double price, int favorite) {
            this.id = id;
            this.name = name;
            this.brand = brand;
            this.flavor = flavor;
            this.price = price;
            this.favorite = favorite;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getBrand() {
            return brand;
        }

        public void setBrand(String brand) {
            this.brand = brand;
        }

        public String getFlavor() {
            return flavor;
        }

        public void setFlavor(String flavor) {
            this.flavor = flavor;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.price = price;
        }

        public int getFavorite() {
            return favorite;
        }

        public void setFavorite(int favorite) {
            this.favorite = favorite;
        }
    }

    public class CandyListAdapter extends ArrayAdapter<CandyItem> {

        public CandyListAdapter(Context context, ArrayList<CandyItem> candyList) {
            super(context, 0, candyList);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_candy, parent, false);
            }

            // Get the candy item at the current position
            CandyItem candyItem = getItem(position);

            // Set the candy name, brand, and flavor in the list item layout
            TextView nameTextView = convertView.findViewById(R.id.nameTextView);
            nameTextView.setText(candyItem.getName());

            TextView brandTextView = convertView.findViewById(R.id.brandTextView);
            brandTextView.setText(candyItem.getBrand());

            TextView flavorTextView = convertView.findViewById(R.id.flavorTextView);
            flavorTextView.setText(candyItem.getFlavor());

            return convertView;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.candy_options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_sort) {
            openSortMenu();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void openSortMenu() {
        PopupMenu popupMenu = new PopupMenu(this, findViewById(R.id.menu_sort));
        popupMenu.getMenuInflater().inflate(R.menu.candy_sort_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId() == R.id.menu_sort_name_asc) {
                    sortCandyListByName(true);
                    return true;
                } else if (item.getItemId() == R.id.menu_sort_name_desc) {
                    sortCandyListByName(false);
                    return true;
                }
                return false;
            }
        });

        popupMenu.show();
    }

    private void sortCandyListByName(final boolean ascending) {
        Collections.sort(candyList, new Comparator<CandyItem>() {
            @Override
            public int compare(CandyItem item1, CandyItem item2) {
                if (ascending) {
                    return item1.getName().compareToIgnoreCase(item2.getName());
                } else {
                    return item2.getName().compareToIgnoreCase(item1.getName());
                }
            }
        });

        adapter.notifyDataSetChanged();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.candy_context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        CandyItem selectedCandy = adapter.getItem(info.position);

        if (item.getItemId() == R.id.menu_delete) {
            deleteCandyItem(selectedCandy);
            return true;
        } else if (item.getItemId() == R.id.menu_share) {
            shareCandyItem(selectedCandy);
            return true;
        }

        return super.onContextItemSelected(item);
    }

    private void deleteCandyItem(CandyItem candyItem) {
        // Remove the candy item from the list
        candyList.remove(candyItem);
        adapter.notifyDataSetChanged();

        Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
    }

    private void shareCandyItem(CandyItem candyItem) {
        String message = "Name: " + candyItem.getName() +
                "\nBrand: " + candyItem.getBrand() +
                "\nFlavor: " + candyItem.getFlavor() +
                "\nPrice: $" + candyItem.getPrice();

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, message);
        startActivity(Intent.createChooser(intent, "Share via"));
    }
}
